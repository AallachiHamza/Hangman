﻿using System;

namespace Pendu
{
	class Program
	{		
		static string toFind = "magouille";
		static int essais = 6;
		static char[] solution = new char[toFind.Length];
		
		public static void Main(string[] args)
		{
			
		}
		// demander lettre
		public static void AskChar(){
			Console.WriteLine("Tapez une lettre:");
			string userString = Console.ReadLine();
			char userChar = userString[0];
		}
		// comparer lettre
		public static void CompareChar(char toCompare){
			bool isPresent = false;
			for(int i = 0; i < toFind.Length; i++) {
				if(toFind[i] == toCompare){
					solution[i] = toCompare;
					isPresent = true;
				}
			}
			if(!isPresent){
				essais--;
			}
		}
		// afficher solution
		public static void DisplaySolution(){
			for(int i = 0; i < solution.Length; i++) {
				Console.Write(solution[i]);
			}
		}
	}
}